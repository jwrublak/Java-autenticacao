
package retomada;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Banco {
    private static Connection connection;
    
    public static Connection getConnection(){
        if(connection == null){
            try{
                //Class.forName("com.mysql.jdbc.Driver"); //para mysql
                Class.forName("org.postgresql.Driver");//para postgresql
                String host = "localhost";
                String port = "5433";
                String database = "postgres";
                String user = "postgres";
                String pass = "suasenha";//digitar a senha do seu banco
                //String url = "jdbc:mysql://"+host+":"+port+"/"+database; //para mysql
                String url = "jdbc:postgresql://"+host+":"+port+"/"+database;//para postgresql
                connection = DriverManager.getConnection(url, user, pass);                
                
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
    public static void close(){
        if (connection == null){
            throw new RuntimeException("Nenhuma conexão aberta!");
        }
        else{
            try{
                connection.close();
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
    private static byte[] converterUsuarioParaByte(Usuario usuario){
        try{
            ByteArrayOutputStream bao = new ByteArrayOutputStream();
            ObjectOutputStream ous;
            ous = new ObjectOutputStream(bao);
            ous.writeObject(usuario);
            return bao.toByteArray();         
            
        } catch (IOException e) {
            e.printStackTrace();
        }        
        return null;
    }
    private static Usuario converterByteParaUsuario(byte[] clienteAsByte){
        try{
            ByteArrayInputStream bai = new ByteArrayInputStream(clienteAsByte);
            ObjectInputStream ois;        
            ois = new ObjectInputStream(bai);
            return (Usuario) ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public static void salvar (Usuario usuario){
        try{
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO usuario (id, nome, objeto) values(?, ?, ?)");
            ps.setInt(1, usuario.getId());
            ps.setString(2, usuario.getNome());
            ps.setBytes(3, converterUsuarioParaByte(usuario));
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static Usuario carregar(int id){
        try{
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT objeto FROM usuario WHERE id = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            rs.next();
            return converterByteParaUsuario(rs.getBytes(1));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static LinkedList<Usuario> listaUsuarios(){
        LinkedList<Usuario> usuarios = new LinkedList<Usuario>();
        try{
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT objeto FROM usuario");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                Usuario u = converterByteParaUsuario(rs.getBytes(1));
                usuarios.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }
    public static void deleta(int id){
        try{
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete FROM usuario WHERE id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();

            }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void atualizaBanco(Usuario usuario){
        deleta(usuario.getId());
        salvar(usuario);
    }
}
